MyCrowd - Social Media Simulation with AI 
 
REQUIREMENTS: 
1. Ollama must be installed and running on the system 
   Download from: https://ollama.ai/download 
 
INSTRUCTIONS: 
1. Install Ollama from the link above 
2. Run Ollama 
3. Run the included "run_mycrowd.bat" file to start the application 
4. The application will open in your default web browser 
 
NOTE: This application requires Ollama to be running for AI responses. 
